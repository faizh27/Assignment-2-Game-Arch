Controls:
- Swipe down to move forward
- Swipe up to move backward
- Swipe left to rotate camera to the right
- Swipe right to rotate camera to the left


Also modified the c++ code, more specifically, I commented out the contents of the Maze and DisjointSet deconstructors
